package org.Emp.voidgenerator;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public class Voidgenerator extends JavaPlugin implements TabCompleter {

    private List<String> loadedVoidWorlds = new ArrayList<>();

    @Override
    public void onEnable() {
        getLogger().info("╔══════════════════════════════════════╗");
        getLogger().info("║                                      ║");
        getLogger().info("║   VoidGenerator Aktif Edildi!        ║");
        getLogger().info("║   Yaratılışın Boşluğuna Hazır Olun!  ║");
        getLogger().info("║                                      ║");
        getLogger().info("╚══════════════════════════════════════╝");

        // Plugin enable olduğunda tüm void dünyalarını yükle
        loadAllVoidWorlds();

        getCommand("createvoid").setExecutor(this);
        getCommand("gotovoid").setExecutor(this);
        getCommand("gotovoid").setTabCompleter(this);
        getCommand("renamevoid").setExecutor(this);
        getCommand("deletevoid").setExecutor(this);
        getCommand("deletevoid").setTabCompleter(this);
        getCommand("renamevoid").setTabCompleter(this);
        getCommand("listvoids").setExecutor(this);
    }

    @Override
    public void onDisable() {
        getLogger().info("╔══════════════════════════════════════╗");
        getLogger().info("║                                      ║");
        getLogger().info("║   VoidGenerator Devre Dışı Bırakıldı ║");
        getLogger().info("║      Sonsuzluğa Elveda...            ║");
        getLogger().info("║                                      ║");
        getLogger().info("╚══════════════════════════════════════╝");

        // Listeyi temizle
        loadedVoidWorlds.clear();
    }

    private void loadAllVoidWorlds() {
        File serverDirectory = Bukkit.getWorldContainer();
        File[] worldDirectories = serverDirectory.listFiles(File::isDirectory);

        if (worldDirectories != null) {
            for (File worldDir : worldDirectories) {
                String worldName = worldDir.getName();

                // level.dat dosyası var mı kontrol et (geçerli bir dünya mı)
                File levelDat = new File(worldDir, "level.dat");
                if (levelDat.exists()) {
                    // Bu dünya zaten yüklü mü kontrol et
                    if (Bukkit.getWorld(worldName) == null) {
                        try {
                            // Void dünyasını yükle
                            WorldCreator creator = new WorldCreator(worldName);
                            creator.generator(new EmptyWorldGenerator());
                            creator.environment(World.Environment.NORMAL);
                            creator.type(WorldType.FLAT);
                            creator.generateStructures(false);
                            creator.generatorSettings("{\"layers\": [], \"biome\":\"the_void\"}");

                            World world = Bukkit.createWorld(creator);
                            if (world != null) {
                                // Dünya ayarlarını yapılandır
                                configureWorld(world);
                                loadedVoidWorlds.add(worldName);
                                getLogger().info("Void dünyası yüklendi: " + worldName);
                            }
                        } catch (Exception e) {
                            getLogger().log(Level.WARNING, "Dünya yüklenirken hata oluştu: " + worldName, e);
                        }
                    } else {
                        // Dünya zaten yüklü
                        loadedVoidWorlds.add(worldName);
                    }
                }
            }
        }
        getLogger().info("Toplam " + loadedVoidWorlds.size() + " void dünyası yüklendi.");
    }

    private void configureWorld(World world) {
        world.setSpawnFlags(false, false);
        world.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(org.bukkit.GameRule.DO_WEATHER_CYCLE, false);
        world.setGameRule(org.bukkit.GameRule.DO_MOB_SPAWNING, false);
        world.setGameRule(org.bukkit.GameRule.DO_FIRE_TICK, false);
        world.setGameRule(org.bukkit.GameRule.DO_INSOMNIA, false);
        world.setSpawnLocation(8, 65, 8);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (command.getName().equalsIgnoreCase("gotovoid") ||
                command.getName().equalsIgnoreCase("deletevoid") ||
                command.getName().equalsIgnoreCase("renamevoid")) {
            if (args.length == 1) {
                // Tüm void dünya isimlerini tab completion'a ekle
                for (String worldName : loadedVoidWorlds) {
                    if (worldName.toLowerCase().startsWith(args[0].toLowerCase())) {
                        completions.add(worldName);
                    }
                }
            } else if (command.getName().equalsIgnoreCase("renamevoid") && args.length == 2) {
                // Rename için öneri verme
                completions.add("<yeni-isim>");
            }
        }
        return completions;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("createvoid")) {
            return handleCreateVoid(sender, args);
        }
        else if (command.getName().equalsIgnoreCase("gotovoid")) {
            return handleGotoVoid(sender, args);
        }
        else if (command.getName().equalsIgnoreCase("renamevoid")) {
            return handleRenameVoid(sender, args);
        }
        else if (command.getName().equalsIgnoreCase("deletevoid")) {
            return handleDeleteVoid(sender, args);
        }
        else if (command.getName().equalsIgnoreCase("listvoids")) {
            return handleListVoids(sender);
        }
        return false;
    }

    private boolean handleListVoids(CommandSender sender) {
        if (loadedVoidWorlds.isEmpty()) {
            sender.sendMessage("§6§lVOID §8» §fHiç void dünyası bulunamadı!");
        } else {
            sender.sendMessage("§6§lVOID §8» §fMevcut void dünyaları:");
            for (String worldName : loadedVoidWorlds) {
                World world = Bukkit.getWorld(worldName);
                if (world != null) {
                    int playerCount = world.getPlayers().size();
                    sender.sendMessage("§8- §e" + worldName + " §7(§f" + playerCount + " oyuncu§7)");
                } else {
                    sender.sendMessage("§8- §c" + worldName + " §7(§cyüklenmemiş§7)");
                }
            }
        }
        return true;
    }

    private boolean handleCreateVoid(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage("§cKullanım: /createvoid <dünya-ismi>");
            return true;
        }

        String worldName = args[0];

        // Geçersiz karakter kontrolü
        if (!isValidWorldName(worldName)) {
            sender.sendMessage("§c§lVOID §8» §fGeçersiz dünya ismi! Sadece [a-z0-9_-] karakterlerini kullanabilirsiniz.");
            return true;
        }

        // Dünya zaten var mı kontrol et
        if (loadedVoidWorlds.contains(worldName)) {
            sender.sendMessage("§c§lVOID §8» §fBu isimde bir dünya zaten mevcut!");
            return true;
        }

        // Dünya oluştur
        WorldCreator creator = new WorldCreator(worldName);
        creator.generator(new EmptyWorldGenerator());
        creator.environment(World.Environment.NORMAL);
        creator.type(WorldType.FLAT);
        creator.generateStructures(false);
        creator.generatorSettings("{\"layers\": [], \"biome\":\"the_void\"}");

        World world = getServer().createWorld(creator);

        if (world != null) {
            // Dünya ayarlarını yapılandır
            configureWorld(world);

            // Listeye ekle
            loadedVoidWorlds.add(worldName);

            sender.sendMessage("§a§lVOID §8» §fBoş dünya oluşturuldu: §e" + worldName);
            sender.sendMessage("§a§lVOID §8» §fSpawn platformunun ortasına ışınlandınız!");

            // Eğer komutu oyuncu verdiyse, hemen ışınlan
            if (sender instanceof Player) {
                Player player = (Player) sender;
                player.teleport(world.getSpawnLocation());
            }
        } else {
            sender.sendMessage("§c§lVOID §8» §fDünya oluşturulamadı!");
        }

        return true;
    }

    private boolean handleGotoVoid(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cBu komut sadece oyuncular tarafından kullanılabilir!");
            return true;
        }

        Player player = (Player) sender;

        if (args.length < 1) {
            player.sendMessage("§cKullanım: /gotovoid <dünya-ismi>");
            player.sendMessage("§6§lVOID §8» §fMevcut dünyalar: " + getWorldList());
            return true;
        }

        String worldName = args[0];

        // Önce listede var mı kontrol et
        if (!loadedVoidWorlds.contains(worldName)) {
            player.sendMessage("§c§lVOID §8» §fBu isimde bir void dünyası bulunamadı!");
            player.sendMessage("§6§lVOID §8» §fMevcut dünyalar: " + getWorldList());
            return true;
        }

        World world = getServer().getWorld(worldName);

        // Eğer dünya yüklenmemişse, yeniden yükle
        if (world == null) {
            try {
                WorldCreator creator = new WorldCreator(worldName);
                creator.generator(new EmptyWorldGenerator());
                creator.environment(World.Environment.NORMAL);
                creator.type(WorldType.FLAT);
                creator.generateStructures(false);
                creator.generatorSettings("{\"layers\": [], \"biome\":\"the_void\"}");

                world = getServer().createWorld(creator);
                if (world != null) {
                    configureWorld(world);
                }
            } catch (Exception e) {
                getLogger().log(Level.WARNING, "Dünya yüklenirken hata oluştu: " + worldName, e);
            }
        }

        if (world == null) {
            player.sendMessage("§c§lVOID §8» §fDünya yüklenemedi!");
            return true;
        }

        // Işınlanma
        player.teleport(world.getSpawnLocation());
        player.sendMessage("§a§lVOID §8» §f" + worldName + " dünyasına ışınlandınız!");

        return true;
    }

    private boolean handleRenameVoid(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cKullanım: /renamevoid <eski-isim> <yeni-isim>");
            sender.sendMessage("§6§lVOID §8» §fMevcut dünyalar: " + getWorldList());
            return true;
        }

        String oldName = args[0];
        String newName = args[1];

        // Yeni isimde geçersiz karakter kontrolü
        if (!isValidWorldName(newName)) {
            sender.sendMessage("§c§lVOID §8» §fGeçersiz dünya ismi! Sadece [a-z0-9_-] karakterlerini kullanabilirsiniz.");
            return true;
        }

        // Eski dünya listede var mı kontrol et
        if (!loadedVoidWorlds.contains(oldName)) {
            sender.sendMessage("§c§lVOID §8» §f'" + oldName + "' isimli bir void dünyası bulunamadı!");
            sender.sendMessage("§6§lVOID §8» §fMevcut dünyalar: " + getWorldList());
            return true;
        }

        // Yeni isimde dünya var mı kontrol et
        if (loadedVoidWorlds.contains(newName)) {
            sender.sendMessage("§c§lVOID §8» §f'" + newName + "' isimli bir dünya zaten mevcut!");
            return true;
        }

        World world = getServer().getWorld(oldName);
        if (world == null) {
            // Dünya yüklenmemişse, dosya sisteminden kontrol et
            File worldDir = new File(getServer().getWorldContainer(), oldName);
            if (!worldDir.exists()) {
                sender.sendMessage("§c§lVOID §8» §f'" + oldName + "' isimli bir dünya bulunamadı!");
                return true;
            }
        }

        // Ana dünyayı yeniden adlandırmayı engelle
        World defaultWorld = getServer().getWorlds().get(0);
        if (world != null && world.equals(defaultWorld)) {
            sender.sendMessage("§c§lVOID §8» §fAna dünyayı yeniden adlandıramazsınız!");
            return true;
        }

        // Oyuncuları dünyadan çıkar (eğer dünya yüklüyse)
        if (world != null) {
            for (Player player : world.getPlayers()) {
                player.teleport(defaultWorld.getSpawnLocation());
                player.sendMessage("§6§lVOID §8» §fDünya yeniden adlandırıldığı için ana dünyaya ışınlandınız!");
            }

            // Dünyayı boşalt
            if (!getServer().unloadWorld(world, true)) {
                sender.sendMessage("§c§lVOID §8» §fDünya boşaltılamadı! Yeniden adlandırma başarısız.");
                return true;
            }
        }

        // Dünya klasörünü yeniden adlandır
        File oldDir = new File(getServer().getWorldContainer(), oldName);
        File newDir = new File(getServer().getWorldContainer(), newName);

        if (oldDir.renameTo(newDir)) {
            // Listeyi güncelle
            loadedVoidWorlds.remove(oldName);
            loadedVoidWorlds.add(newName);

            // Yeniden adlandırılmış dünyayı yükle
            try {
                WorldCreator creator = new WorldCreator(newName);
                creator.generator(new EmptyWorldGenerator());
                creator.environment(World.Environment.NORMAL);
                creator.type(WorldType.FLAT);
                creator.generateStructures(false);
                creator.generatorSettings("{\"layers\": [], \"biome\":\"the_void\"}");

                World newWorld = getServer().createWorld(creator);
                if (newWorld != null) {
                    configureWorld(newWorld);
                    sender.sendMessage("§a§lVOID §8» §fDünya başarıyla yeniden adlandırıldı: §e" + oldName + " §f→ §a" + newName);
                }
            } catch (Exception e) {
                sender.sendMessage("§c§lVOID §8» §fDünya yüklenirken hata oluştu!");
                getLogger().log(Level.WARNING, "Dünya yüklenirken hata oluştu: " + newName, e);
            }
        } else {
            sender.sendMessage("§c§lVOID §8» §fDünya yeniden adlandırılamadı! Klasör işlemi başarısız.");
            // Eski dünyayı geri yükle
            if (oldDir.exists()) {
                WorldCreator creator = new WorldCreator(oldName);
                creator.generator(new EmptyWorldGenerator());
                getServer().createWorld(creator);
                loadedVoidWorlds.add(oldName);
            }
        }

        return true;
    }

    private boolean handleDeleteVoid(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage("§cKullanım: /deletevoid <dünya-ismi>");
            sender.sendMessage("§6§lVOID §8» §fMevcut dünyalar: " + getWorldList());
            return true;
        }

        String worldName = args[0];

        // Önce listede var mı kontrol et
        if (!loadedVoidWorlds.contains(worldName)) {
            sender.sendMessage("§c§lVOID §8» §f'" + worldName + "' isimli bir void dünyası bulunamadı!");
            sender.sendMessage("§6§lVOID §8» §fMevcut dünyalar: " + getWorldList());
            return true;
        }

        World world = getServer().getWorld(worldName);

        // Ana dünyayı silmeyi engelle
        World defaultWorld = getServer().getWorlds().get(0);
        if (world != null && world.equals(defaultWorld)) {
            sender.sendMessage("§c§lVOID §8» §fAna dünyayı silemezsiniz!");
            return true;
        }

        // Oyuncuları dünyadan çıkar (eğer dünya yüklüyse)
        if (world != null) {
            for (Player player : world.getPlayers()) {
                player.teleport(defaultWorld.getSpawnLocation());
                player.sendMessage("§6§lVOID §8» §fDünya silindiği için ana dünyaya ışınlandınız!");
            }

            // Dünyayı boşalt
            if (!getServer().unloadWorld(world, false)) {
                sender.sendMessage("§c§lVOID §8» §fDünya boşaltılamadı! Silme işlemi başarısız.");
                return true;
            }
        }

        // Dünya klasörünü sil
        File worldDir = new File(getServer().getWorldContainer(), worldName);
        if (deleteDirectory(worldDir)) {
            // Listeden kaldır
            loadedVoidWorlds.remove(worldName);
            sender.sendMessage("§a§lVOID §8» §fDünya başarıyla silindi: §e" + worldName);
        } else {
            sender.sendMessage("§c§lVOID §8» §fDünya klasörü silinemedi! Manuel olarak silmeniz gerekebilir.");
        }

        return true;
    }

    private boolean deleteDirectory(File directory) {
        if (directory.exists()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        deleteDirectory(file);
                    } else {
                        file.delete();
                    }
                }
            }
        }
        return directory.delete();
    }

    private String getWorldList() {
        if (loadedVoidWorlds.isEmpty()) {
            return "§cHiç void dünyası yok";
        }
        List<String> worldNames = new ArrayList<>();
        for (String worldName : loadedVoidWorlds) {
            worldNames.add("§e" + worldName + "§f");
        }
        return String.join(", ", worldNames);
    }

    // Geçerli dünya ismi kontrol metodu
    private boolean isValidWorldName(String name) {
        return name.matches("^[a-zA-Z0-9_-]+$");
    }
}